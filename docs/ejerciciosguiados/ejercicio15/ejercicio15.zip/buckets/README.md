# Microservicio de Gestión de Imágenes

Microservicio Flask para la administración de imágenes almacenadas en Google Cloud Storage con autenticación y base de datos MariaDB.

## Características

- ✅ Subida de imágenes a GCS
- ✅ Listado y visualización de imágenes
- ✅ URLs firmadas (válidas por 1 hora)
- ✅ Operaciones CRUD completas
- ✅ Autenticación con token Bearer
- ✅ Respuestas en XML/JSON
- ✅ Documentación Swagger/OpenAPI
- ✅ Registro en base de datos MariaDB

## Requisitos

- Python 3.8+
- MariaDB/MySQL
- Cuenta de Google Cloud Platform
- Bucket en Google Cloud Storage

## Instalación

### 1. Clonar y configurar entorno

```bash
# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# Instalar dependencias
pip install -r requirements.txt
```

### 2. Configuración de Base de Datos

```bash
# Conectar a MariaDB y ejecutar el script
mysql -u root -p < images.sql
```

### 3. Configuración de Google Cloud

```bash
# Crear bucket en GCS
gsutil mb -l us-central1 gs://margarita-images

# Configurar cuenta de servicio
gcloud iam service-accounts create flask-image-service \
    --description="Service account para microservicio de imagenes" \
    --display-name="Flask Images Service"

# Asignar permisos al bucket
gsutil iam ch serviceAccount:flask-image-service@TU_PROYECTO.iam.gserviceaccount.com:objectAdmin gs://margarita-images

# Descargar clave de servicio
gcloud iam service-accounts keys create service-account-key.json \
    --iam-account=flask-image-service@TU_PROYECTO.iam.gserviceaccount.com
```

### 4. Variables de Entorno

Crear archivo `.env`:

```bash
# Archivo .env
export API_TOKEN="04c573825d6d1cc93485c19dad738688bac19392"  # SHA1 de 'udem'
export MYSQL_HOST="localhost"
export MYSQL_USER="images_user"
export MYSQL_PASSWORD="666"
export MYSQL_DB="images"
export GCS_BUCKET_NAME="margarita-images"
export GOOGLE_APPLICATION_CREDENTIALS="/ruta/completa/service-account-key.json"
```

### 5. Ejecutar la aplicación

```bash
# Cargar variables de entorno
source .env

# Ejecutar la aplicación
export FLASK_APP="app.py"
flask run --host=0.0.0.0
```

La aplicación estará disponible en: `http://[IP_EXTERNA_DE_LA_VM]:5000`

## Documentación API

La documentación Swagger está disponible en: `http://[IP_EXTERNA_DE_LA_VM]:5000/swagger/`

## Uso de la API

### Autenticación

Todas las rutas requieren autenticación Bearer Token:

```
Authorization: Bearer udem
```

### Ejemplos con curl

#### 1. Subir una imagen (CREATE)

```bash
# Sin autenticación (debe fallar)
curl -X POST http://localhost:5000/upload \
  -F "file=@imagen.jpg"

# Con autenticación (éxito)
curl -X POST http://localhost:5000/upload \
  -H "Authorization: Bearer udem" \
  -F "file=@imagen.jpg"

# Con formato JSON explícito
curl -X POST http://localhost:5000/upload?format=json \
  -H "Authorization: Bearer udem" \
  -F "file=@imagen.jpg"
```

#### 2. Listar imágenes (READ)

```bash
# Sin autenticación (debe fallar)
curl -X GET http://localhost:5000/images

# Con autenticación (éxito)
curl -X GET http://localhost:5000/images \
  -H "Authorization: Bearer udem"

# En formato JSON
curl -X GET "http://localhost:5000/images?format=json" \
  -H "Authorization: Bearer udem"
```

#### 3. Obtener imagen específica (READ)

```bash
curl -X GET http://localhost:5000/images/1 \
  -H "Authorization: Bearer udem"
```

#### 4. Actualizar imagen (UPDATE)

```bash
curl -X PUT http://localhost:5000/images/1 \
  -H "Authorization: Bearer udem" \
  -F "file=@nueva_imagen.jpg"
```

#### 5. Eliminar imagen (DELETE)

```bash
curl -X DELETE http://localhost:5000/images/1 \
  -H "Authorization: Bearer udem"
```

#### 6. Verificar salud del servicio

```bash
curl -X GET http://localhost:5000/health
```

## Estructura de Respuestas

### Formato XML (por defecto)

```xml
<response>
  <message>Imagen subida exitosamente</message>
  <filename>20241103_170000_image.jpg</filename>
  <signed_url>https://storage.googleapis.com/...</signed_url>
  <file_size>1024000</file_size>
  <mime_type>image/jpeg</mime_type>
</response>
```

### Formato JSON (con ?format=json)

```json
{
  "message": "Imagen subida exitosamente",
  "filename": "20241103_170000_image.jpg",
  "signed_url": "https://storage.googleapis.com/...",
  "file_size": 1024000,
  "mime_type": "image/jpeg"
}
```

## Formatos de imagen soportados

- PNG
- JPG
- JPEG
- GIF

Tamaño máximo: 16 MB por archivo.

## Endpoints disponibles

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/upload` | Subir nueva imagen |
| GET | `/images` | Listar todas las imágenes |
| GET | `/images/<id>` | Obtener imagen específica |
| PUT | `/images/<id>` | Actualizar imagen |
| DELETE | `/images/<id>` | Eliminar imagen |
| GET | `/health` | Verificar estado del servicio |
| GET | `/swagger/` | Documentación Swagger |

## Seguridad

- Autenticación Bearer Token con hash SHA1
- Validación de tipos de archivo
- Nombres de archivo seguros con `secure_filename`
- Tamaño máximo de archivo configurado

## Solución de problemas

### Error de conexión a MySQL

Verificar que el servicio MariaDB esté ejecutándose:

```bash
sudo systemctl status mariadb
```

### Error de permisos en GCS

Verificar que la cuenta de servicio tenga permisos:

```bash
gsutil iam get gs://margarita-images
```

### Error de autenticación

Verificar que el token sea correcto:

```bash
echo -n "udem" | sha1sum
```

## Licencia

MIT License
```

## Estructura final del proyecto:

```
Microservices/
│
├── Buckets/
    ├── app.py                          # Microservicio Flask principal
    ├── requirements.txt                # Dependencias de Python
    ├── images.sql                      # Script de creación de tabla MariaDB
    ├── .env                           # Variables de entorno (NO subir a Git)
    ├── service-account-key.json       # Credenciales GCP (NO subir a Git)
    ├── README.md                      # Documentación del proyecto
```

## Comandos rápidos para empezar:

```bash
# 1. Instalar dependencias
pip install -r requirements.txt

# 2. Configurar base de datos
mysql -u root -p < images.sql

# 3. Configurar variables de entorno
cp .env.example .env
# Editar .env con tus valores

# 4. Ejecutar la aplicación
source .env
python app.py
```

¡Tu microservicio está listo para usar! 🚀