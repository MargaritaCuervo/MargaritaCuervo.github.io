#app.py
from flask import Flask, request, jsonify, Response
from flask_mysqldb import MySQL
from google.cloud import storage
from google.auth import credentials
import os
from datetime import datetime, timedelta
import json
import xml.etree.ElementTree as ET
from werkzeug.utils import secure_filename
from functools import wraps
import hashlib
from flasgger import Swagger, swag_from

app = Flask(__name__)

# Configuración de Flasgger
app.config['SWAGGER'] = {
    'title': 'Microservicio de Imágenes API',
    'description': 'API CRUD para gestión de imágenes en Google Cloud Storage',
    'uiversion': 3,
    'specs_route': '/swagger/',
    'headers': [],
    'specs': [
        {
            'endpoint': 'apispec',
            'route': '/apispec.json',
            'rule_filter': lambda rule: True,
            'model_filter': lambda tag: True,
        }
    ],
    'static_url_path': '/flasgger_static',
    'swagger_ui': True,
    'specs_route': '/swagger/'
}

swagger = Swagger(app)

# Configuración
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST', 'localhost')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER', 'root')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD', '')
app.config['MYSQL_DB'] = os.getenv('MYSQL_DB', 'image_service')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

# Inicializar MySQL
mysql = MySQL(app)

# Configurar Google Cloud Storage
bucket_name = os.getenv('GCS_BUCKET_NAME', 'margarita-images')
if os.path.exists('credentials.json'):
    storage_client = storage.Client.from_service_account_json('credentials.json')
else:
    storage_client = storage.Client()
bucket = storage_client.bucket(bucket_name)

# Función para verificar extensiones de archivo
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Función para verificar tokens con SHA1
def verify_api_token(token):
    stored_hash = os.getenv('API_TOKEN')
    if not stored_hash:
        return False
    token_hash = hashlib.sha1(token.encode('utf-8')).hexdigest()
    return token_hash == stored_hash

# Decorador de autenticación
def require_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return format_response({'error': 'Token requerido'}, 401)
        
        token = auth_header.split(' ')[1]
        if not verify_api_token(token):
            return format_response({'error': 'Token inválido'}, 401)
        
        return f(*args, **kwargs)
    return decorated_function

def format_response(data, status_code=200):
    format_type = request.args.get('format', 'xml')
    
    if format_type == 'json':
        return jsonify(data), status_code
    else:
        root = ET.Element('response')
        def build_xml(element, data):
            if isinstance(data, dict):
                for key, value in data.items():
                    child = ET.SubElement(element, key)
                    build_xml(child, value)
            elif isinstance(data, list):
                for item in data:
                    child = ET.SubElement(element, 'item')
                    build_xml(child, item)
            else:
                element.text = str(data)
        
        build_xml(root, data)
        xml_str = ET.tostring(root, encoding='unicode')
        return Response(xml_str, mimetype='application/xml'), status_code

def init_db():
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            CREATE TABLE IF NOT EXISTS images (
                id INT AUTO_INCREMENT PRIMARY KEY,
                filename VARCHAR(255) NOT NULL,
                upload_date DATETIME NOT NULL,
                file_size BIGINT NOT NULL,
                mime_type VARCHAR(100) NOT NULL,
                url TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        mysql.connection.commit()
        cur.close()
        print("Base de datos inicializada correctamente")
    except Exception as e:
        print(f"Error inicializando base de datos: {e}")

# CREATE - Subir imagen
@app.route('/upload', methods=['POST'])
@require_auth
@swag_from({
    'tags': ['Images'],
    'summary': 'Subir una nueva imagen',
    'description': 'Subir una imagen al bucket de Google Cloud Storage',
    'consumes': ['multipart/form-data'],
    'parameters': [
        {
            'name': 'Authorization',
            'in': 'header',
            'type': 'string',
            'required': True,
            'description': 'Token de autorización: Bearer <token>'
        },
        {
            'name': 'file',
            'in': 'formData',
            'type': 'file',
            'required': True,
            'description': 'Archivo de imagen a subir (png, jpg, jpeg, gif)'
        }
    ],
    'responses': {
        201: {
            'description': 'Imagen subida exitosamente',
            'examples': {
                'application/json': {
                    'message': 'Imagen subida exitosamente',
                    'filename': '20241103_170000_image.jpg',
                    'signed_url': 'https://storage.googleapis.com/...',
                    'file_size': 1024000,
                    'mime_type': 'image/jpeg'
                }
            }
        },
        400: {
            'description': 'Error en la solicitud',
            'examples': {
                'application/json': {
                    'error': 'Tipo de archivo no permitido'
                }
            }
        },
        401: {
            'description': 'No autorizado',
            'examples': {
                'application/json': {
                    'error': 'Token requerido'
                }
            }
        },
        500: {
            'description': 'Error interno del servidor',
            'examples': {
                'application/json': {
                    'error': 'Error subiendo archivo'
                }
            }
        }
    }
})
def upload_image():
    """Subir una imagen al bucket de GCS"""
    try:
        if 'file' not in request.files:
            return format_response({'error': 'No se encontró el archivo'}, 400)
        
        file = request.files['file']
        if file.filename == '':
            return format_response({'error': 'Nombre de archivo vacío'}, 400)
        
        if not allowed_file(file.filename):
            return format_response({'error': 'Tipo de archivo no permitido'}, 400)
        
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_")
        unique_filename = timestamp + filename
        
        # Subir a Google Cloud Storage
        blob = bucket.blob(unique_filename)
        blob.upload_from_string(
            file.read(),
            content_type=file.content_type
        )
        
        # Generar URL firmada
        signed_url = blob.generate_signed_url(
            expiration=timedelta(hours=1),
            version='v4'
        )
        
        # Registrar en la base de datos
        cur = mysql.connection.cursor()
        cur.execute('''
            INSERT INTO images (filename, upload_date, file_size, mime_type, url)
            VALUES (%s, %s, %s, %s, %s)
        ''', (unique_filename, datetime.now(), blob.size, file.content_type, signed_url))
        mysql.connection.commit()
        cur.close()
        
        return format_response({
            'message': 'Imagen subida exitosamente',
            'filename': unique_filename,
            'signed_url': signed_url,
            'file_size': blob.size,
            'mime_type': file.content_type
        }, 201)
        
    except Exception as e:
        return format_response({'error': f'Error subiendo archivo: {str(e)}'}, 500)

# READ - Listar todas las imágenes
@app.route('/images', methods=['GET'])
@require_auth
@swag_from({
    'tags': ['Images'],
    'summary': 'Listar todas las imágenes',
    'description': 'Obtener la lista de todas las imágenes almacenadas',
    'parameters': [
        {
            'name': 'Authorization',
            'in': 'header',
            'type': 'string',
            'required': True,
            'description': 'Token de autorización: Bearer <token>'
        },
        {
            'name': 'format',
            'in': 'query',
            'type': 'string',
            'required': False,
            'enum': ['json', 'xml'],
            'default': 'xml',
            'description': 'Formato de respuesta (json o xml)'
        }
    ],
    'responses': {
        200: {
            'description': 'Lista de imágenes obtenida exitosamente',
            'examples': {
                'application/json': {
                    'images': [
                        {
                            'id': 1,
                            'filename': '20241103_170000_image.jpg',
                            'url': 'https://storage.googleapis.com/...',
                            'upload_date': '2024-11-03 17:00:00',
                            'file_size': 1024000,
                            'mime_type': 'image/jpeg'
                        }
                    ],
                    'count': 1
                }
            }
        },
        401: {
            'description': 'No autorizado'
        },
        500: {
            'description': 'Error interno del servidor'
        }
    }
})
def list_images():
    """Listar todas las imágenes del bucket"""
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            SELECT id, filename, url, upload_date, file_size, mime_type 
            FROM images 
            ORDER BY upload_date DESC
        ''')
        images = cur.fetchall()
        cur.close()
        
        image_list = []
        for img in images:
            image_list.append({
                'id': img[0],
                'filename': img[1],
                'url': img[2],
                'upload_date': img[3].strftime('%Y-%m-%d %H:%M:%S'),
                'file_size': img[4],
                'mime_type': img[5]
            })
        
        return format_response({'images': image_list, 'count': len(image_list)})
        
    except Exception as e:
        return format_response({'error': f'Error obteniendo imágenes: {str(e)}'}, 500)

# READ - Obtener una imagen específica
@app.route('/images/<int:image_id>', methods=['GET'])
@require_auth
@swag_from({
    'tags': ['Images'],
    'summary': 'Obtener imagen específica',
    'description': 'Obtener los detalles de una imagen específica por ID',
    'parameters': [
        {
            'name': 'Authorization',
            'in': 'header',
            'type': 'string',
            'required': True,
            'description': 'Token de autorización: Bearer <token>'
        },
        {
            'name': 'image_id',
            'in': 'path',
            'type': 'integer',
            'required': True,
            'description': 'ID de la imagen'
        },
        {
            'name': 'format',
            'in': 'query',
            'type': 'string',
            'required': False,
            'enum': ['json', 'xml'],
            'default': 'xml',
            'description': 'Formato de respuesta (json o xml)'
        }
    ],
    'responses': {
        200: {
            'description': 'Imagen encontrada',
            'examples': {
                'application/json': {
                    'image': {
                        'id': 1,
                        'filename': '20241103_170000_image.jpg',
                        'url': 'https://storage.googleapis.com/...',
                        'upload_date': '2024-11-03 17:00:00',
                        'file_size': 1024000,
                        'mime_type': 'image/jpeg'
                    }
                }
            }
        },
        404: {
            'description': 'Imagen no encontrada'
        },
        401: {
            'description': 'No autorizado'
        },
        500: {
            'description': 'Error interno del servidor'
        }
    }
})
def get_image(image_id):
    """Obtener los detalles de una imagen específica"""
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            SELECT id, filename, url, upload_date, file_size, mime_type 
            FROM images 
            WHERE id = %s
        ''', (image_id,))
        image = cur.fetchone()
        cur.close()
        
        if image:
            image_data = {
                'id': image[0],
                'filename': image[1],
                'url': image[2],
                'upload_date': image[3].strftime('%Y-%m-%d %H:%M:%S'),
                'file_size': image[4],
                'mime_type': image[5]
            }
            return format_response({'image': image_data})
        else:
            return format_response({'error': 'Imagen no encontrada'}, 404)
        
    except Exception as e:
        return format_response({'error': f'Error obteniendo imagen: {str(e)}'}, 500)

# UPDATE - Actualizar una imagen
@app.route('/images/<int:image_id>', methods=['PUT'])
@require_auth
@swag_from({
    'tags': ['Images'],
    'summary': 'Actualizar imagen',
    'description': 'Actualizar o reemplazar una imagen existente',
    'consumes': ['multipart/form-data'],
    'parameters': [
        {
            'name': 'Authorization',
            'in': 'header',
            'type': 'string',
            'required': True,
            'description': 'Token de autorización: Bearer <token>'
        },
        {
            'name': 'image_id',
            'in': 'path',
            'type': 'integer',
            'required': True,
            'description': 'ID de la imagen a actualizar'
        },
        {
            'name': 'file',
            'in': 'formData',
            'type': 'file',
            'required': True,
            'description': 'Nuevo archivo de imagen'
        }
    ],
    'responses': {
        200: {
            'description': 'Imagen actualizada exitosamente',
            'examples': {
                'application/json': {
                    'message': 'Imagen actualizada exitosamente',
                    'id': 1,
                    'new_filename': '20241103_170000_new_image.jpg',
                    'signed_url': 'https://storage.googleapis.com/...',
                    'file_size': 1024000,
                    'mime_type': 'image/jpeg'
                }
            }
        },
        400: {
            'description': 'Error en la solicitud'
        },
        404: {
            'description': 'Imagen no encontrada'
        },
        401: {
            'description': 'No autorizado'
        },
        500: {
            'description': 'Error interno del servidor'
        }
    }
})
def update_image(image_id):
    """Actualizar/reemplazar una imagen existente"""
    try:
        # Verificar si la imagen existe
        cur = mysql.connection.cursor()
        cur.execute('SELECT filename FROM images WHERE id = %s', (image_id,))
        existing_image = cur.fetchone()
        
        if not existing_image:
            cur.close()
            return format_response({'error': 'Imagen no encontrada'}, 404)
        
        if 'file' not in request.files:
            cur.close()
            return format_response({'error': 'No se encontró el archivo'}, 400)
        
        file = request.files['file']
        if file.filename == '':
            cur.close()
            return format_response({'error': 'Nombre de archivo vacío'}, 400)
        
        if not allowed_file(file.filename):
            cur.close()
            return format_response({'error': 'Tipo de archivo no permitido'}, 400)
        
        old_filename = existing_image[0]
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_")
        new_filename = timestamp + filename
        
        # Eliminar el archivo antiguo de GCS
        old_blob = bucket.blob(old_filename)
        if old_blob.exists():
            old_blob.delete()
        
        # Subir el nuevo archivo a GCS
        new_blob = bucket.blob(new_filename)
        new_blob.upload_from_string(
            file.read(),
            content_type=file.content_type
        )
        
        # Generar nueva URL firmada
        new_signed_url = new_blob.generate_signed_url(
            expiration=timedelta(hours=1),
            version='v4'
        )
        
        # Actualizar en la base de datos
        cur.execute('''
            UPDATE images 
            SET filename = %s, upload_date = %s, file_size = %s, mime_type = %s, url = %s 
            WHERE id = %s
        ''', (new_filename, datetime.now(), new_blob.size, file.content_type, new_signed_url, image_id))
        mysql.connection.commit()
        cur.close()
        
        return format_response({
            'message': 'Imagen actualizada exitosamente',
            'id': image_id,
            'new_filename': new_filename,
            'signed_url': new_signed_url,
            'file_size': new_blob.size,
            'mime_type': file.content_type
        })
        
    except Exception as e:
        return format_response({'error': f'Error actualizando imagen: {str(e)}'}, 500)

# DELETE - Eliminar una imagen
@app.route('/images/<int:image_id>', methods=['DELETE'])
@require_auth
@swag_from({
    'tags': ['Images'],
    'summary': 'Eliminar imagen',
    'description': 'Eliminar una imagen del bucket y la base de datos',
    'parameters': [
        {
            'name': 'Authorization',
            'in': 'header',
            'type': 'string',
            'required': True,
            'description': 'Token de autorización: Bearer <token>'
        },
        {
            'name': 'image_id',
            'in': 'path',
            'type': 'integer',
            'required': True,
            'description': 'ID de la imagen a eliminar'
        }
    ],
    'responses': {
        200: {
            'description': 'Imagen eliminada exitosamente',
            'examples': {
                'application/json': {
                    'message': 'Imagen eliminada exitosamente',
                    'deleted_id': 1,
                    'filename': '20241103_170000_image.jpg'
                }
            }
        },
        404: {
            'description': 'Imagen no encontrada'
        },
        401: {
            'description': 'No autorizado'
        },
        500: {
            'description': 'Error interno del servidor'
        }
    }
})
def delete_image(image_id):
    """Eliminar una imagen del bucket y la base de datos"""
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT filename FROM images WHERE id = %s', (image_id,))
        image = cur.fetchone()
        
        if not image:
            cur.close()
            return format_response({'error': 'Imagen no encontrada'}, 404)
        
        filename = image[0]
        
        # Eliminar de Google Cloud Storage
        blob = bucket.blob(filename)
        if blob.exists():
            blob.delete()
        
        # Eliminar de la base de datos
        cur.execute('DELETE FROM images WHERE id = %s', (image_id,))
        mysql.connection.commit()
        cur.close()
        
        return format_response({
            'message': 'Imagen eliminada exitosamente',
            'deleted_id': image_id,
            'filename': filename
        })
        
    except Exception as e:
        return format_response({'error': f'Error eliminando imagen: {str(e)}'}, 500)

# Health Check
@app.route('/health', methods=['GET'])
@swag_from({
    'tags': ['Health'],
    'summary': 'Verificar estado del servicio',
    'description': 'Endpoint para verificar que el servicio está funcionando',
    'responses': {
        200: {
            'description': 'Servicio funcionando correctamente',
            'examples': {
                'application/json': {
                    'status': 'healthy',
                    'timestamp': '2024-11-03T17:00:00'
                }
            }
        }
    }
})
def health_check():
    """Endpoint de salud"""
    return format_response({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
