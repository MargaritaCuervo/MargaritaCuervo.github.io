from locust import HttpUser, task, between, SequentialTaskSet
import json
import random

class BookstoreTaskSet(SequentialTaskSet):
    """
    Conjunto de tareas secuenciales que simulan el flujo de un usuario real
    """
    
    def on_start(self):
        """Se ejecuta cuando un usuario virtual inicia"""
        # Registrar un usuario único para esta sesión
        self.username = f"user_{random.randint(1000, 999999)}"
        self.password = "testpass123"
        self.access_token = None
        self.refresh_token = None
        
        # Registrar usuario
        self.register_user()
        # Hacer login
        self.login_user()
    
    def register_user(self):
        """Registra un nuevo usuario"""
        response = self.client.post(
            "/auth/register",
            json={
                "username": self.username,
                "password": self.password
            },
            name="AUTH: Register"
        )
        if response.status_code in [201, 409]:  # 409 si ya existe
            return True
        return False
    
    def login_user(self):
        """Realiza login y obtiene tokens"""
        response = self.client.post(
            "/auth/login",
            json={
                "username": self.username,
                "password": self.password
            },
            name="AUTH: Login"
        )
        if response.status_code == 200:
            data = response.json()
            self.access_token = data.get("access_token")
            self.refresh_token = data.get("refresh_token")
            return True
        return False
    
    def get_headers(self):
        """Retorna headers con token de autorización"""
        if self.access_token:
            return {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }
        return {"Content-Type": "application/json"}
    
    @task(5)
    def get_all_books(self):
        """Obtiene todos los libros (tarea frecuente)"""
        self.client.get(
            "/api/books",
            headers=self.get_headers(),
            name="BOOKS: Get All"
        )
    
    @task(3)
    def get_book_by_isbn(self):
        """Busca un libro por ISBN"""
        # ISBNs de ejemplo - ajusta según tu BD
        sample_isbns = [
            "978-0-123456-78-9",
            "978-1-234567-89-0",
            "978-2-345678-90-1",
            "ISBN-EJEMPLO"
        ]
        isbn = random.choice(sample_isbns)
        self.client.get(
            f"/api/books/ISBN?isbn={isbn}",
            headers=self.get_headers(),
            name="BOOKS: Get by ISBN"
        )
    
    @task(2)
    def get_books_by_format(self):
        """Busca libros por formato"""
        formats = ["Tapa dura", "Tapa blanda", "Digital", "eBook"]
        fmt = random.choice(formats)
        self.client.get(
            f"/api/books/format/?format={fmt}",
            headers=self.get_headers(),
            name="BOOKS: Get by Format"
        )
    
    @task(2)
    def get_books_by_author(self):
        """Busca libros por autor"""
        authors = ["García", "Martínez", "López", "Pérez"]
        author = random.choice(authors)
        self.client.get(
            f"/api/books/autor/?name={author}",
            headers=self.get_headers(),
            name="BOOKS: Get by Author"
        )
    
    @task(1)
    def create_book(self):
        """Crea un nuevo libro"""
        isbn = f"978-{random.randint(0,9)}-{random.randint(100000,999999)}-{random.randint(10,99)}-{random.randint(0,9)}"
        book_data = {
            "isbn": isbn,
            "titulo": f"Libro de Prueba {random.randint(1, 9999)}",
            "id_autor": random.randint(1, 10),
            "id_categoria": random.randint(1, 5),
            "id_editorial": random.randint(1, 5),
            "anio_publicacion": random.randint(2000, 2024),
            "price": round(random.uniform(10.0, 100.0), 2),
            "stock": random.randint(0, 100),
            "formato": random.choice(["Tapa dura", "Tapa blanda", "Digital"])
        }
        self.client.post(
            "/api/books/create",
            json=book_data,
            headers=self.get_headers(),
            name="BOOKS: Create"
        )
    
    @task(1)
    def update_book(self):
        """Actualiza un libro existente"""
        # Usa un ISBN de ejemplo
        isbn = "978-0-123456-78-9"
        update_data = {
            "isbn": isbn,
            "price": round(random.uniform(10.0, 150.0), 2),
            "stock": random.randint(0, 200)
        }
        self.client.put(
            "/api/books/update",
            json=update_data,
            headers=self.get_headers(),
            name="BOOKS: Update"
        )
    
    @task(1)
    def refresh_access_token(self):
        """Refresca el access token usando refresh token"""
        if self.refresh_token:
            response = self.client.post(
                "/auth/refresh",
                headers={
                    "Authorization": f"Bearer {self.refresh_token}",
                    "Content-Type": "application/json"
                },
                name="AUTH: Refresh Token"
            )
            if response.status_code == 200:
                data = response.json()
                self.access_token = data.get("access_token")
    
    def on_stop(self):
        """Se ejecuta cuando el usuario virtual termina"""
        # Hacer logout
        if self.access_token:
            self.client.post(
                "/auth/logout",
                headers=self.get_headers(),
                name="AUTH: Logout"
            )


class BookstoreUser(HttpUser):
    """
    Clase principal que define el comportamiento del usuario virtual
    """
    tasks = [BookstoreTaskSet]
    
    # Tiempo de espera entre tareas (en segundos)
    wait_time = between(1, 3)  # Espera entre 1 y 3 segundos
    
    # Host base (se puede sobrescribir en línea de comandos)
    host = "http://127.0.0.1:5000"


# === ESCENARIOS ADICIONALES (OPCIONALES) ===

class HeavyLoadUser(HttpUser):
    """
    Usuario que genera carga pesada sin esperas
    """
    tasks = [BookstoreTaskSet]
    wait_time = between(0.1, 0.5)  # Espera muy corta
    host = "http://127.0.0.1:5000"


class ReadOnlyUser(HttpUser):
    """
    Usuario que solo realiza operaciones de lectura
    """
    wait_time = between(1, 2)
    host = "http://127.0.0.1:5000"
    
    @task(10)
    def get_all_books(self):
        # Primero login
        username = f"readonly_{random.randint(1000, 9999)}"
        self.client.post("/auth/register", json={"username": username, "password": "test"})
        response = self.client.post("/auth/login", json={"username": username, "password": "test"})
        
        if response.status_code == 200:
            token = response.json().get("access_token")
            self.client.get(
                "/api/books",
                headers={"Authorization": f"Bearer {token}"},
                name="READ: Get All Books"
            )