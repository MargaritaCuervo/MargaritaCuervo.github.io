from flask import Flask, request, jsonify, Response, make_response
from flask_cors import CORS
from datetime import timedelta, datetime, timezone
from flask_jwt_extended import (
    JWTManager, create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt
)
from flask_jwt_extended.utils import decode_token
from passlib.hash import pbkdf2_sha256
import MySQLdb
import xml.etree.ElementTree as ET
import redis
import os
from flasgger import Swagger, swag_from
from google.cloud import storage
from werkzeug.utils import secure_filename
import json

# =========================
# App & Config
# =========================
app = Flask(__name__)

# JWT
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'a3f8c7e1d9b5a2f4e6c8a9b1d3e5f7a2c4b6d8e0f2a1c3e5b7d9f1a3c5e7b9d1')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=15)
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)
app.config['JWT_TOKEN_LOCATION'] = ['headers']
app.config['JWT_HEADER_NAME'] = 'Authorization'
app.config['JWT_HEADER_TYPE'] = 'Bearer'
jwt = JWTManager(app)

# Swagger Configuration
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'apispec',
            "route": '/apispec.json',
            "rule_filter": lambda rule: True,
            "model_filter": lambda tag: True,
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/api/docs"
}

swagger_template = {
    "swagger": "2.0",
    "info": {
        "title": "API de Gestión de Libros con Imágenes",
        "description": "Microservicio para gestión de libros con autenticación JWT y almacenamiento de imágenes en Google Cloud Storage.",
        "version": "2.0.0",
        "contact": {
            "name": "API Support",
            "email": "support@libros.com"
        }
    },
    "basePath": "/",
    "schemes": ["http", "https"],
    "securityDefinitions": {
        "Bearer": {
            "type": "apiKey",
            "name": "Authorization",
            "in": "header",
            "description": "JWT Authorization header using the Bearer scheme. Example: 'Bearer {token}'"
        }
    }
}

swagger = Swagger(app, config=swagger_config, template=swagger_template)

# CORS
CORS(
    app,
    resources={r"/*": {"origins": "*"}},
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
    expose_headers=["Content-Type", "Authorization"],
    supports_credentials=False,
    send_wildcard=True,
    max_age=86400,
)

# MariaDB
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER", "libro_user")
DB_PASS = os.getenv("DB_PASS", "666")
DB_NAME = os.getenv("DB_NAME", "Libros")
DB_CHARSET = "utf8"

def get_db():
    return MySQLdb.connect(
        host=DB_HOST, user=DB_USER, passwd=DB_PASS,
        db=DB_NAME, charset=DB_CHARSET
    )

# Redis
REDIS_HOST = os.getenv("REDIS_HOST", "127.0.0.1")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_DB   = int(os.getenv("REDIS_DB", "0"))
r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, decode_responses=True)

# Google Cloud Storage Configuration
GCS_BUCKET_NAME = os.getenv('GCS_BUCKET_NAME', 'books-images-bucket')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
MAX_IMAGES = 5

# Initialize GCS client
try:
    if os.path.exists('credentials.json'):
        storage_client = storage.Client.from_service_account_json('credentials.json')
    else:
        storage_client = storage.Client()
    bucket = storage_client.bucket(GCS_BUCKET_NAME)
    # Test bucket access
    bucket.exists()
    print(f"✅ GCS Bucket configurado: {GCS_BUCKET_NAME}")
except Exception as e:
    print(f"⚠️  Error configurando GCS: {e}")
    storage_client = None
    bucket = None

# =========================
# Helpers: JWT + Redis + GCS
# =========================
def _now_ts():
    return int(datetime.now(timezone.utc).timestamp())

def _ttl_from_exp(exp_unix: int) -> int:
    ttl = exp_unix - _now_ts()
    return ttl if ttl > 0 else 1

def _allow_key(token_type: str, jti: str) -> str:
    return f"allow:{token_type}:{jti}"

def _block_key(jti: str) -> str:
    return f"block:{jti}"

def store_in_allowlist(encoded_token: str, token_type: str, username: str):
    decoded = decode_token(encoded_token)
    jti = decoded['jti']
    exp = decoded['exp']
    ttl = _ttl_from_exp(exp)
    key = _allow_key(token_type, jti)
    r.hset(key, mapping={"username": username, "type": token_type, "exp": str(exp)})
    r.expire(key, ttl)
    return jti

def is_in_allowlist(jti: str) -> bool:
    return r.exists(_allow_key("access", jti)) == 1 or r.exists(_allow_key("refresh", jti)) == 1

def is_revoked(jti: str) -> bool:
    return r.exists(_block_key(jti)) == 1

def revoke_jti(jti: str, exp: int):
    ttl = _ttl_from_exp(exp)
    r.setex(_block_key(jti), ttl, "1")
    r.delete(_allow_key("access", jti))
    r.delete(_allow_key("refresh", jti))

@jwt.token_in_blocklist_loader
def token_check_revoked(jwt_header, jwt_payload):
    jti = jwt_payload["jti"]
    return is_revoked(jti) or (not is_in_allowlist(jti))

# GCS Helper Functions
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_to_gcs(file, isbn):
    """Sube archivo a GCS y retorna URL pública"""
    if not bucket:
        raise Exception("GCS bucket no configurado")
    
    filename = secure_filename(file.filename)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique_filename = f"{isbn}_{timestamp}_{filename}"
    
    blob = bucket.blob(unique_filename)
    blob.upload_from_string(
        file.read(),
        content_type=file.content_type
    )
    
    # Hacer el archivo público
    blob.make_public()
    
    return blob.public_url, unique_filename

def delete_from_gcs(filename):
    """Elimina archivo de GCS"""
    if not bucket or not filename:
        return
    
    try:
        blob = bucket.blob(filename)
        if blob.exists():
            blob.delete()
    except Exception as e:
        print(f"Error eliminando archivo de GCS: {e}")

# Preflight (CORS)
@app.before_request
def handle_preflight():
    if request.method == "OPTIONS":
        resp = make_response()
        resp.headers["Access-Control-Allow-Origin"] = request.headers.get("Origin", "*")
        resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
        return resp, 200

@app.after_request
def add_cors_headers(resp):
    resp.headers["Access-Control-Allow-Origin"] = request.headers.get("Origin", "*")
    resp.headers["Vary"] = "Origin"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
    return resp

# =========================
# XML helpers (actualizado para imágenes)
# =========================
def books_to_xml(rows):
    catalog = ET.Element('catalog')
    for b in rows:
        book_elem = ET.Element('book', isbn=b.get('isbn', ''))
        
        # Campos existentes
        title = ET.SubElement(book_elem, 'title'); title.text = b.get('titulo', 'Desconocido')
        
        # Autores
        authors_field = b.get('authors') or b.get('autor') or ''
        authors = authors_field.split(',') if authors_field else []
        if not authors:
            ET.SubElement(book_elem, 'author').text = 'Desconocido'
        else:
            for a in authors:
                ET.SubElement(book_elem, 'author').text = a.strip()

        year = ET.SubElement(book_elem, 'year'); year.text = str(b.get('anio_publicacion', '0'))
        genre = ET.SubElement(book_elem, 'genre'); genre.text = b.get('genre_name', b.get('genero', 'Desconocido'))
        price = ET.SubElement(book_elem, 'price'); price.text = str(b.get('price', '0.0'))
        stock = ET.SubElement(book_elem, 'stock'); stock.text = str(b.get('stock', '0'))
        fmt = ET.SubElement(book_elem, 'format'); fmt.text = b.get('formato', 'Desconocido')
        
        # Nuevo: Imágenes
        images_field = b.get('images', '[]')
        try:
            images = json.loads(images_field) if images_field else []
        except:
            images = []
        
        images_elem = ET.SubElement(book_elem, 'images')
        for img_url in images:
            ET.SubElement(images_elem, 'image').text = img_url
        
        catalog.append(book_elem)
    return ET.tostring(catalog, encoding='utf-8', xml_declaration=True)

# =========================
# AUTH
# =========================

@app.route('/auth/register', methods=['POST'])
def register():
    """
    Registrar nuevo usuario
    ---
    tags:
      - Autenticación
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - username
            - password
          properties:
            username:
              type: string
            password:
              type: string
    responses:
      201:
        description: Usuario registrado exitosamente
      400:
        description: Usuario ya existe o datos faltantes
      500:
        description: Error del servidor
    """
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        
        if not username or not password:
            return jsonify({"msg": "username y password requeridos"}), 400
        
        conn = get_db()
        cur = conn.cursor(MySQLdb.cursors.DictCursor)
        
        # Verificar si el usuario ya existe
        cur.execute("SELECT username FROM Users WHERE username = %s", (username,))
        if cur.fetchone():
            return jsonify({"msg": "Usuario ya existe"}), 400
        
        # Hash de la contraseña
        hashed_password = pbkdf2_sha256.hash(password)
        
        # Insertar usuario
        cur.execute(
            "INSERT INTO Users (username, password_hash) VALUES (%s, %s)",
            (username, hashed_password)
        )
        conn.commit()
        
        return jsonify({"msg": "Usuario registrado exitosamente"}), 201
        
    except Exception as e:
        return jsonify({"msg": f"Error: {str(e)}"}), 500
    finally:
        try:
            conn.close()
        except:
            pass

@app.route('/auth/login', methods=['POST'])
def login():
    """
    Iniciar sesión y obtener tokens JWT
    ---
    tags:
      - Autenticación
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - username
            - password
          properties:
            username:
              type: string
            password:
              type: string
    responses:
      200:
        description: Login exitoso, retorna access y refresh tokens
      401:
        description: Credenciales inválidas
      500:
        description: Error del servidor
    """
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        
        if not username or not password:
            return jsonify({"msg": "username y password requeridos"}), 400
        
        conn = get_db()
        cur = conn.cursor(MySQLdb.cursors.DictCursor)
        
        # Buscar usuario
        cur.execute("SELECT username, password_hash FROM Users WHERE username = %s", (username,))
        user = cur.fetchone()
        
        if not user or not pbkdf2_sha256.verify(password, user['password_hash']):
            return jsonify({"msg": "Credenciales inválidas"}), 401
        
        # Crear tokens
        access_token = create_access_token(identity=username)
        refresh_token = create_refresh_token(identity=username)
        
        # Guardar en allowlist (Redis)
        store_in_allowlist(access_token, "access", username)
        store_in_allowlist(refresh_token, "refresh", username)
        
        return jsonify({
            "access_token": access_token,
            "refresh_token": refresh_token,
            "username": username
        }), 200
        
    except Exception as e:
        return jsonify({"msg": f"Error: {str(e)}"}), 500
    finally:
        try:
            conn.close()
        except:
            pass

@app.route('/auth/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh_token():
    """
    Refrescar token de acceso usando refresh token
    ---
    tags:
      - Autenticación
    security:
      - Bearer: []
    responses:
      200:
        description: Nuevo access token generado
      401:
        description: Refresh token inválido
    """
    try:
        username = get_jwt_identity()
        new_access_token = create_access_token(identity=username)
        store_in_allowlist(new_access_token, "access", username)
        
        return jsonify({"access_token": new_access_token}), 200
        
    except Exception as e:
        return jsonify({"msg": f"Error: {str(e)}"}), 500

@app.route('/auth/logout', methods=['POST'])
@jwt_required()
def logout():
    """
    Cerrar sesión y revocar token actual
    ---
    tags:
      - Autenticación
    security:
      - Bearer: []
    responses:
      200:
        description: Sesión cerrada exitosamente
      401:
        description: Token inválido
    """
    try:
        jwt_data = get_jwt()
        jti = jwt_data['jti']
        exp = jwt_data['exp']
        
        # Revocar el token
        revoke_jti(jti, exp)
        
        return jsonify({"msg": "Sesión cerrada exitosamente"}), 200
        
    except Exception as e:
        return jsonify({"msg": f"Error: {str(e)}"}), 500

# =========================
# BOOKS ENDPOINTS (MODIFICADOS PARA IMÁGENES)
# =========================

@app.route('/api/books', methods=['GET'])
@jwt_required()
def books_all():
    """
    Obtener todos los libros en formato XML
    ---
    tags:
      - Libros
    security:
      - Bearer: []
    produces:
      - application/xml
    responses:
      200:
        description: Catálogo completo de libros en XML (incluye imágenes)
        schema:
          type: string
    """
    try:
        conn = get_db(); cur = conn.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("""
            SELECT l.isbn, l.titulo, l.anio_publicacion, l.price, l.stock, l.formato, l.images,
                   GROUP_CONCAT(a.nombre SEPARATOR ',') AS authors,
                   c.nombre AS genre_name
            FROM Libro l
            LEFT JOIN Autor a ON l.id_autor = a.id_autor
            LEFT JOIN Categoria c ON l.id_categoria = c.id_categoria
            GROUP BY l.isbn
        """)
        rows = cur.fetchall()
        xml = books_to_xml(rows)
        return Response(xml, mimetype='application/xml', status=200)
    except Exception as e:
        err = f"<?xml version='1.0' encoding='UTF-8'?><error>{str(e)}</error>"
        return Response(err, mimetype='application/xml', status=500)
    finally:
        try: conn.close()
        except: pass

@app.route('/api/books/create', methods=['POST'], strict_slashes=False)
@jwt_required()
def book_create():
    """
    Crear un nuevo libro con imágenes
    ---
    tags:
      - Libros
    security:
      - Bearer: []
    consumes:
      - multipart/form-data
    parameters:
      - in: header
        name: Authorization
        required: true
        type: string
      - in: formData
        name: isbn
        type: string
        required: true
      - in: formData
        name: titulo
        type: string
        required: true
      - in: formData
        name: id_autor
        type: integer
        required: true
      - in: formData
        name: id_categoria
        type: integer
        required: true
      - in: formData
        name: id_editorial
        type: integer
        required: true
      - in: formData
        name: anio_publicacion
        type: integer
        required: true
      - in: formData
        name: price
        type: number
        required: true
      - in: formData
        name: stock
        type: integer
        required: true
      - in: formData
        name: formato
        type: string
        required: true
      - in: formData
        name: images
        type: file
        required: false
        description: Máximo 5 imágenes (JPG, PNG), 5MB cada una
    produces:
      - application/xml
    responses:
      201:
        description: Libro creado exitosamente con imágenes
      400:
        description: Error en validación de datos o imágenes
      500:
        description: Error del servidor
    """
    try:
        # Obtener datos del formulario
        data = request.form
        files = request.files
        
        # Validar campos requeridos
        req_fields = ['isbn','titulo','id_autor','id_categoria','id_editorial',
                     'anio_publicacion','price','stock','formato']
        if any(field not in data for field in req_fields):
            return Response("<?xml version='1.0'?><error>faltan campos requeridos</error>",
                            mimetype='application/xml', status=400)
        
        isbn = data['isbn']
        
        # Procesar imágenes
        image_files = files.getlist('images')
        image_urls = []
        
        # Validar número de imágenes
        if len(image_files) > MAX_IMAGES:
            return Response(f"<?xml version='1.0'?><error>Máximo {MAX_IMAGES} imágenes permitidas</error>",
                            mimetype='application/xml', status=400)
        
        for file in image_files:
            if file and file.filename:
                # Validar tipo de archivo
                if not allowed_file(file.filename):
                    return Response("<?xml version='1.0'?><error>Tipo de archivo no permitido. Solo JPG, PNG</error>",
                                    mimetype='application/xml', status=400)
                
                # Validar tamaño
                file_data = file.read()
                if len(file_data) > MAX_FILE_SIZE:
                    return Response("<?xml version='1.0'?><error>Archivo demasiado grande. Máximo 5MB</error>",
                                    mimetype='application/xml', status=400)
                file.seek(0)  # Reset file pointer
                
                # Subir a GCS
                try:
                    image_url, filename = upload_to_gcs(file, isbn)
                    image_urls.append(image_url)
                except Exception as e:
                    return Response(f"<?xml version='1.0'?><error>Error subiendo imagen: {str(e)}</error>",
                                    mimetype='application/xml', status=500)
        
        # Convertir URLs a JSON
        images_json = json.dumps(image_urls)
        
        # Insertar en base de datos
        conn = get_db(); cur = conn.cursor()
        cur.execute("""
            INSERT INTO Libro (isbn, titulo, id_autor, id_categoria, id_editorial,
                               anio_publicacion, price, stock, formato, images)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (data['isbn'], data['titulo'], data['id_autor'], data['id_categoria'],
              data['id_editorial'], data['anio_publicacion'], data['price'],
              data['stock'], data['formato'], images_json))
        conn.commit()
        
        return Response("<?xml version='1.0'?><ok>inserted</ok>",
                        mimetype='application/xml', status=201)
        
    except Exception as e:
        err = f"<?xml version='1.0'?><error>{str(e)}</error>"
        return Response(err, mimetype='application/xml', status=500)
    finally:
        try: conn.close()
        except: pass

@app.route('/api/books/update', methods=['PUT'], strict_slashes=False)
@jwt_required()
def book_update():
    """
    Actualizar un libro existente (con soporte para imágenes)
    ---
    tags:
      - Libros
    security:
      - Bearer: []
    consumes:
      - multipart/form-data
    parameters:
      - in: header
        name: Authorization
        required: true
        type: string
      - in: formData
        name: isbn
        type: string
        required: true
      - in: formData
        name: titulo
        type: string
        required: false
      - in: formData
        name: id_autor
        type: integer
        required: false
      - in: formData
        name: id_categoria
        type: integer
        required: false
      - in: formData
        name: id_editorial
        type: integer
        required: false
      - in: formData
        name: anio_publicacion
        type: integer
        required: false
      - in: formData
        name: price
        type: number
        required: false
      - in: formData
        name: stock
        type: integer
        required: false
      - in: formData
        name: formato
        type: string
        required: false
      - in: formData
        name: images
        type: file
        required: false
        description: Nuevas imágenes (reemplazan las existentes)
      - in: formData
        name: replace_images
        type: boolean
        required: false
        description: Si true, reemplaza todas las imágenes existentes
    produces:
      - application/xml
    responses:
      200:
        description: Libro actualizado exitosamente
      400:
        description: Error en la solicitud
      500:
        description: Error del servidor
    """
    try:
        data = request.form
        files = request.files
        isbn = data.get('isbn')
        
        if not isbn:
            return Response("<?xml version='1.0'?><error>isbn requerido</error>",
                            mimetype='application/xml', status=400)
        
        # Obtener libro actual
        conn = get_db(); cur = conn.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT images FROM Libro WHERE isbn = %s", (isbn,))
        existing_book = cur.fetchone()
        
        if not existing_book:
            return Response("<?xml version='1.0'?><error>Libro no encontrado</error>",
                            mimetype='application/xml', status=404)
        
        # Procesar imágenes
        image_files = files.getlist('images')
        replace_images = data.get('replace_images', 'false').lower() == 'true'
        
        if image_files and image_files[0].filename:
            # Validar número de imágenes
            if len(image_files) > MAX_IMAGES:
                return Response(f"<?xml version='1.0'?><error>Máximo {MAX_IMAGES} imágenes permitidas</error>",
                                mimetype='application/xml', status=400)
            
            image_urls = []
            
            # Si reemplazamos imágenes, eliminamos las antiguas
            if replace_images and existing_book['images']:
                try:
                    old_images = json.loads(existing_book['images'])
                    # En una implementación real, necesitarías almacenar los nombres de archivo en GCS
                    # para poder eliminarlos. Por simplicidad, aquí solo limpiamos las URLs.
                except:
                    pass
            
            for file in image_files:
                if file and file.filename:
                    # Validaciones
                    if not allowed_file(file.filename):
                        return Response("<?xml version='1.0'?><error>Tipo de archivo no permitido</error>",
                                        mimetype='application/xml', status=400)
                    
                    file_data = file.read()
                    if len(file_data) > MAX_FILE_SIZE:
                        return Response("<?xml version='1.0'?><error>Archivo demasiado grande</error>",
                                        mimetype='application/xml', status=400)
                    file.seek(0)
                    
                    # Subir a GCS
                    try:
                        image_url, filename = upload_to_gcs(file, isbn)
                        image_urls.append(image_url)
                    except Exception as e:
                        return Response(f"<?xml version='1.0'?><error>Error subiendo imagen: {str(e)}</error>",
                                        mimetype='application/xml', status=500)
            
            # Actualizar imágenes
            if image_urls:
                images_json = json.dumps(image_urls)
                data = dict(data)  # Convertir a dict mutable
                data['images'] = images_json
        
        # Actualizar otros campos
        fields = {k:v for k,v in data.items() if k in [
            'titulo','id_autor','id_categoria','id_editorial',
            'anio_publicacion','price','stock','formato', 'images'
        ] and v not in (None, '')}
        
        if not fields:
            return Response("<?xml version='1.0'?><error>nada que actualizar</error>",
                            mimetype='application/xml', status=400)
        
        sets = ", ".join([f"{k}=%s" for k in fields.keys()])
        params = list(fields.values()) + [isbn]
        cur.execute(f"UPDATE Libro SET {sets} WHERE isbn=%s", params)
        conn.commit()
        
        return Response("<?xml version='1.0'?><ok>updated</ok>",
                        mimetype='application/xml', status=200)
        
    except Exception as e:
        err = f"<?xml version='1.0'?><error>{str(e)}</error>"
        return Response(err, mimetype='application/xml', status=500)
    finally:
        try: conn.close()
        except: pass

# Los otros endpoints (GET por ISBN, autor, formato, DELETE) permanecen igual
# pero se actualizan para incluir el campo 'images' en las consultas

@app.route('/api/books/ISBN', methods=['GET'], strict_slashes=False)
@jwt_required()
def books_by_isbn():
    """Buscar libro por ISBN (actualizado para imágenes)"""
    isbn = request.args.get('isbn', '').strip()
    if not isbn:
        return Response("<?xml version='1.0'?><error>isbn requerido</error>",
                        mimetype='application/xml', status=400)
    try:
        conn = get_db(); cur = conn.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("""
            SELECT l.isbn, l.titulo, l.anio_publicacion, l.price, l.stock, l.formato, l.images,
                   GROUP_CONCAT(a.nombre SEPARATOR ',') AS authors,
                   c.nombre AS genre_name
            FROM Libro l
            LEFT JOIN Autor a ON l.id_autor = a.id_autor
            LEFT JOIN Categoria c ON l.id_categoria = c.id_categoria
            WHERE l.isbn = %s
            GROUP BY l.isbn
        """, (isbn,))
        rows = cur.fetchall()
        xml = books_to_xml(rows)
        return Response(xml, mimetype='application/xml', status=200)
    except Exception as e:
        err = f"<?xml version='1.0'?><error>{str(e)}</error>"
        return Response(err, mimetype='application/xml', status=500)
    finally:
        try: conn.close()
        except: pass

@app.route('/api/books/delete', methods=['DELETE'], strict_slashes=False)
@jwt_required()
def book_delete():
    """
    Eliminar un libro por ISBN (incluye eliminación de imágenes en GCS)
    ---
    tags:
      - Libros
    security:
      - Bearer: []
    parameters:
      - in: query
        name: isbn
        type: string
        required: true
        description: ISBN del libro a eliminar
      - in: header
        name: Authorization
        required: true
        type: string
    produces:
      - application/xml
    responses:
      200:
        description: Libro eliminado exitosamente
      400:
        description: ISBN no proporcionado
      404:
        description: Libro no encontrado
      500:
        description: Error del servidor
    """
    try:
        isbn = request.args.get('isbn', '').strip()
        
        if not isbn:
            return Response("<?xml version='1.0'?><e>isbn requerido</e>",
                            mimetype='application/xml', status=400)
        
        conn = get_db()
        cur = conn.cursor(MySQLdb.cursors.DictCursor)
        
        # Obtener información del libro (incluyendo imágenes) antes de eliminarlo
        cur.execute("SELECT images FROM Libro WHERE isbn = %s", (isbn,))
        book = cur.fetchone()
        
        if not book:
            return Response("<?xml version='1.0'?><e>Libro no encontrado</e>",
                            mimetype='application/xml', status=404)
        
        # Eliminar imágenes de GCS si existen
        if book['images']:
            try:
                images = json.loads(book['images'])
                # Extraer nombres de archivo de las URLs y eliminarlos
                for img_url in images:
                    # Extraer el nombre del archivo de la URL
                    # Formato típico: https://storage.googleapis.com/bucket-name/filename
                    if img_url:
                        filename = img_url.split('/')[-1]
                        delete_from_gcs(filename)
            except Exception as e:
                print(f"Advertencia: Error eliminando imágenes de GCS: {e}")
                # Continuar con la eliminación del libro aunque falle la eliminación de imágenes
        
        # Eliminar el libro de la base de datos
        cur.execute("DELETE FROM Libro WHERE isbn = %s", (isbn,))
        conn.commit()
        
        if cur.rowcount == 0:
            return Response("<?xml version='1.0'?><e>Libro no encontrado</e>",
                            mimetype='application/xml', status=404)
        
        return Response("<?xml version='1.0'?><ok>deleted</ok>",
                        mimetype='application/xml', status=200)
        
    except Exception as e:
        err = f"<?xml version='1.0'?><e>{str(e)}</e>"
        return Response(err, mimetype='application/xml', status=500)
    finally:
        try:
            conn.close()
        except:
            pass

# Health check mejorado
@app.route('/ping', methods=['GET'])
def ping():
    """
    Health check endpoint
    ---
    tags:
      - Utilidades
    responses:
      200:
        description: Servicio funcionando correctamente
    """
    status = {
        "msg": "pong",
        "gcs_configured": bucket is not None,
        "timestamp": datetime.now().isoformat()
    }
    return jsonify(status), 200

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
