# 📚 Microservicio de Gestión de Libros

Microservicio RESTful para la gestión de libros con autenticación JWT, almacenamiento de imágenes en Google Cloud Storage y respuestas en formato XML.

## 🚀 Características

- ✅ **Autenticación JWT** con tokens de acceso y refresco
- ✅ **Gestión de libros** completa (CRUD)
- ✅ **Almacenamiento de imágenes** en Google Cloud Storage
- ✅ **Redis** para allowlist/blocklist de tokens
- ✅ **Respuestas en XML** para todos los endpoints de libros
- ✅ **Documentación interactiva** con Swagger/Flasgger
- ✅ **CORS** configurado para integración con frontends
- ✅ **Seguridad** con hash de contraseñas usando passlib

## 🛠️ Tecnologías Utilizadas

- **Flask** - Framework web
- **Flask-JWT-Extended** - Autenticación JWT
- **Flask-CORS** - Manejo de CORS
- **Flasgger** - Documentación Swagger
- **MariaDB/MySQL** - Base de datos
- **Redis** - Caché y gestión de tokens
- **Google Cloud Storage** - Almacenamiento de imágenes
- **Passlib** - Hash de contraseñas
- **Python 3.9+**

## 📋 Requisitos Previos

- Python 3.9 o superior
- MariaDB/MySQL
- Redis Server
- Google Cloud Platform (cuenta y proyecto configurado)
- Credenciales de GCP en formato JSON

## 📦 Instalación

### 1. Descargar proyecto

Descargar .zip

### 2. Instalar dependencias

```bash
pip install flask flask-cors flask-jwt-extended mysqlclient redis passlib flasgger google-cloud-storage --break-system-packages
```

### 3. Configurar variables de entorno

Crear un archivo `.env` en la raíz del proyecto:

```bash
# Base de datos
export MYSQL_HOST="localhost"
export MYSQL_USER="libros_user"
export MYSQL_PASSWORD="666"
export MYSQL_DB="Libros"

# JWT
JWT_SECRET_KEY=a3f8c7e1d9b5a2f4e6c8a9b1d3e5f7a2c4b6d8e0f2a1c3e5b7d9f1a3c5e7b9d1

# Google Cloud Storage
export GCS_BUCKET_NAME="margarita-books-images-bucket"
export GOOGLE_APPLICATION_CREDENTIALS="/ruta/al/archivo/credentials.json"

# Redis (opcional, usa valores por defecto si no se especifica)
export REDIS_HOST="127.0.0.1"
export REDIS_PORT="6379"
export REDIS_DB="0"
```

### 4. Cargar variables de entorno

```bash
source .env
```

## 🗄️ Configuración de la Base de Datos

### Crear la base de datos

```sql
CREATE DATABASE Libros CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Crear tabla de usuarios

```sql
USE Libros;

CREATE TABLE `Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=563 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
```

### Crear tabla de libros

```sql
CREATE TABLE `Libro` (
  `id_libro` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `id_autor` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_editorial` int(11) NOT NULL,
  `anio_publicacion` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `formato` varchar(50) NOT NULL,
  `images` text DEFAULT '[]',
  PRIMARY KEY (`id_libro`),
  KEY `id_autor` (`id_autor`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_editorial` (`id_editorial`),
  CONSTRAINT `Libro_ibfk_1` FOREIGN KEY (`id_autor`) REFERENCES `Autor` (`id_autor`),
  CONSTRAINT `Libro_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `Categoria` (`id_categoria`),
  CONSTRAINT `Libro_ibfk_3` FOREIGN KEY (`id_editorial`) REFERENCES `Editorial` (`id_editorial`)
) ENGINE=InnoDB AUTO_INCREMENT=232 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
```

### Crear tablas relacionadas

```sql
CREATE TABLE `Autor` (
  `id_autor` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `nacionalidad` varchar(50) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`id_autor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `Categoria` (
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `Editorial` (
  `id_editorial` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `pais` varchar(50) DEFAULT NULL,
  `anio_fundacion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_editorial`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
```

## 🚀 Ejecución

### Iniciar el servidor

```bash
export FLASK_APP="app.py"
flask run --host=0.0.0.0
```

El servidor estará disponible en:
- **Local:** http://localhost:5000
- **Red:** http://[IP_EXTERNA_DE_LA_VM]:5000

### Aplicación Web

Accede a la página web interactiva del microservicio:

**URL:** `http://[IP_EXTERNA_DE_LA_VM]:8080`


### Verificar que el servicio está funcionando

```bash
curl http://[IP_EXTERNA_DE_LA_VM]:5000/ping
```

Respuesta esperada:
```json
{
  "msg": "pong",
  "gcs_configured": true,
  "timestamp": "2025-11-24T12:00:00"
}
```

## 📚 Documentación de la API

### Swagger UI

Accede a la documentación interactiva en:

**URL:** `http://[IP_EXTERNA_DE_LA_VM]:5000/api/docs`

Desde Swagger puedes:
- Ver todos los endpoints disponibles
- Probar cada endpoint de forma interactiva
- Ver los esquemas de request/response
- Autenticarte y probar endpoints protegidos

## 🔐 Autenticación

### 1. Registrar un nuevo usuario

**Endpoint:** `POST /auth/register`

**Body:**
```json
{
  "username": "libro_user2",
  "password": "666"
}
```

**Respuesta (201):**
```json
{
  "msg": "Usuario registrado exitosamente"
}
```

### 2. Iniciar sesión

**Endpoint:** `POST /auth/login`

**Body:**
```json
{
  "username": "libro_user2",
  "password": "666"
}
```

**Respuesta (200):**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "username": "libro_user2"
}
```

### 3. Usar el token

Para endpoints protegidos, incluye el token en el header:

```
Authorization: Bearer <access_token>
```

### 4. Renovar token

**Endpoint:** `POST /auth/refresh`

**Headers:**
```
Authorization: Bearer <refresh_token>
```

**Respuesta (200):**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

### 5. Cerrar sesión

**Endpoint:** `POST /auth/logout`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Respuesta (200):**
```json
{
  "msg": "Sesión cerrada exitosamente"
}
```

## 📖 Endpoints de Libros

### Listar todos los libros

**Endpoint:** `GET /api/books`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Respuesta (200):**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<catalog>
  <book isbn="9781234567890">
    <title>El Quijote</title>
    <author>Miguel de Cervantes</author>
    <year>1605</year>
    <genre>Novela</genre>
    <price>29.99</price>
    <stock>10</stock>
    <format>Tapa Dura</format>
    <images>
      <image>https://storage.googleapis.com/bucket/image1.jpg</image>
    </images>
  </book>
</catalog>
```

### Buscar libro por ISBN

**Endpoint:** `GET /api/books/ISBN?isbn=9781234567890`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Respuesta:** XML con el libro encontrado

### Crear un nuevo libro

**Endpoint:** `POST /api/books/create`

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: multipart/form-data
```

**Form Data:**
- `isbn` (string, requerido): ISBN del libro
- `titulo` (string, requerido): Título del libro
- `id_autor` (int, requerido): ID del autor
- `id_categoria` (int, requerido): ID de la categoría
- `id_editorial` (int, requerido): ID de la editorial
- `anio_publicacion` (int, requerido): Año de publicación
- `price` (float, requerido): Precio del libro
- `stock` (int, requerido): Cantidad en stock
- `formato` (string, requerido): Formato (ej: "Tapa Dura")
- `images` (file, opcional): Imágenes del libro (máximo 5, JPG/PNG, 5MB cada una)

**Respuesta (201):**
```xml
<?xml version='1.0'?>
<ok>inserted</ok>
```

### Actualizar un libro

**Endpoint:** `PUT /api/books/update`

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: multipart/form-data
```

**Form Data:**
- `isbn` (string, requerido): ISBN del libro a actualizar
- Cualquier campo que se quiera actualizar (todos opcionales excepto isbn)
- `images` (file, opcional): Nuevas imágenes
- `replace_images` (boolean, opcional): Si es true, reemplaza todas las imágenes existentes

**Respuesta (200):**
```xml
<?xml version='1.0'?>
<ok>updated</ok>
```

### Eliminar un libro

**Endpoint:** `DELETE /api/books/delete?isbn=9781234567890`

**Headers:**
```
Authorization: Bearer <access_token>
```

**Respuesta (200):**
```xml
<?xml version='1.0'?>
<ok>deleted</ok>
```

**Nota:** Este endpoint también elimina las imágenes asociadas del libro en Google Cloud Storage.

## 🖼️ Manejo de Imágenes

### Características

- **Formatos permitidos:** JPG, JPEG, PNG
- **Tamaño máximo:** 5MB por imagen
- **Cantidad máxima:** 5 imágenes por libro
- **Almacenamiento:** Google Cloud Storage
- **Acceso:** URLs públicas generadas automáticamente

### Estructura en base de datos

Las imágenes se almacenan en el campo `images` como un array JSON:

```json
[
  "https://storage.googleapis.com/bucket/isbn_timestamp_image1.jpg",
  "https://storage.googleapis.com/bucket/isbn_timestamp_image2.jpg"
]
```

## 🔧 Configuración de Google Cloud Storage

### 1. Crear un bucket

```bash
gsutil mb gs://tu-bucket-name
```

### 2. Configurar permisos públicos (opcional)

```bash
gsutil iam ch allUsers:objectViewer gs://tu-bucket-name
```

### 3. Obtener credenciales

1. Ve a Google Cloud Console
2. IAM & Admin > Service Accounts
3. Create Service Account
4. Asigna rol "Storage Object Admin"
5. Create Key > JSON
6. Guarda el archivo JSON y configura la ruta en `.env`

## ⚠️ Manejo de Errores

### Códigos de respuesta

| Código | Descripción |
|--------|-------------|
| 200 | Operación exitosa |
| 201 | Recurso creado exitosamente |
| 400 | Error en la solicitud (datos inválidos) |
| 401 | No autenticado o token inválido |
| 404 | Recurso no encontrado |
| 500 | Error interno del servidor |

### Formato de errores

**JSON (autenticación):**
```json
{
  "msg": "Credenciales inválidas"
}
```

**XML (libros):**
```xml
<?xml version='1.0'?>
<e>Error: descripción del error</e>
```

## 🔒 Seguridad

### Contraseñas

- Hash usando **PBKDF2-SHA256** con salt
- Nunca se almacenan contraseñas en texto plano
- Implementado con la librería `passlib`

### Tokens JWT

- **Access Token:** Expira en 15 minutos
- **Refresh Token:** Expira en 30 días
- Almacenados en Redis con sistema de allowlist/blocklist
- Revocación automática al hacer logout

### CORS

- Configurado para aceptar requests de cualquier origen (desarrollo)
- Para producción, especifica los orígenes permitidos

## 📊 Monitoreo

### Health Check

**Endpoint:** `GET /ping`

Verifica el estado del servicio y la configuración de GCS.

```bash
curl http://localhost:5000/ping
```

### Redis

Verificar conexión a Redis:

```bash
redis-cli ping
# Respuesta esperada: PONG
```

### Base de datos

Verificar conexión a MySQL:

```bash
mysql -u libros_user -p -h localhost Libros
```

## 🐛 Solución de Problemas

### Error: "Unknown column 'password' in 'field list'"

**Causa:** La tabla Users usa `password_hash` pero el código busca `password`

**Solución:** Asegúrate de usar la versión correcta del código que usa `password_hash`

### Error: "GCS bucket no configurado"

**Causa:** Credenciales de GCP no configuradas correctamente

**Solución:**
1. Verifica que el archivo `credentials.json` existe
2. Verifica la variable `GOOGLE_APPLICATION_CREDENTIALS` en `.env`
3. Verifica que el bucket existe en GCP

### Error: "Token has been revoked"

**Causa:** Token fue revocado o no está en la allowlist

**Solución:** Haz login nuevamente para obtener un nuevo token

### Error 500 en endpoints de libros

**Causa:** Tablas relacionadas (Autor, Categoria, Editorial) no existen o no tienen datos

**Solución:** Crea las tablas e inserta datos de prueba:

```sql
INSERT INTO Autor (nombre) VALUES ('Autor de Prueba');
INSERT INTO Categoria (nombre) VALUES ('Ficción');
INSERT INTO Editorial (nombre) VALUES ('Editorial de Prueba');
```

## 🧪 Pruebas

### Probar con cURL

#### Registro
```bash
curl -X POST http://[IP_EXTERNA_DE_LA_VM]:5000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"libro_user2","password":"666"}'
```

#### Login
```bash
curl -X POST http://[IP_EXTERNA_DE_LA_VM]:5000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"libro_user2","password":"666"}'
```

#### Listar libros
```bash
curl -X GET http://[IP_EXTERNA_DE_LA_VM]:5000/api/books \
  -H "Authorization: Bearer TU_ACCESS_TOKEN"
```

## 📝 Notas Importantes

- El servidor usa `debug=True` en desarrollo. **Deshabilita debug en producción**
- Para producción, usa un servidor WSGI como Gunicorn o uWSGI
- Cambia el `JWT_SECRET_KEY` por uno seguro y único
- Configura CORS para permitir solo orígenes específicos en producción
- Los tokens tienen tiempo de expiración configurado (15 min access, 30 días refresh)

## 👥 Autor

Margarita Concepción Cuervo Citalán #581771

## 📄 Licencia

Este proyecto es parte de un trabajo académico.

---

**Nota:** Este microservicio está diseñado para propósitos educativos y de desarrollo. Para uso en producción, se recomienda implementar medidas de seguridad adicionales.
