# break_point_test.py
import math
from locust import HttpUser, LoadTestShape
# Importamos tus usuarios reales del proyecto
from users import DoctorUser, PatientUser, InstitutionUser

try:
    import reporting
except ImportError:
    pass

class StepLoadShape(LoadTestShape):
    """
    Prueba de Punto de Quiebre (Break Point):
    Aumenta la carga en escalones hasta encontrar el límite.
    """
    step_time = 60       # Duración de cada escalón (60 segundos)
    step_users = 50      # Usuarios nuevos por escalón
    spawn_rate = 5       # Tasa de nacimiento (5 usuarios/seg)

    def tick(self):
        run_time = self.get_run_time()

        # Calcula en qué escalón vamos (Minuto 1 = Escalón 1, Minuto 2 = Escalón 2...)
        current_step = math.floor(run_time / self.step_time) + 1
        
        # Calcula los usuarios totales para este escalón
        target_users = current_step * self.step_users
        
        # Le dice a Locust cuántos usuarios debe haber ahora
        return (target_users, self.spawn_rate)